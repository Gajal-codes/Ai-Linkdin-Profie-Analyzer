import { useState, useEffect, createContext, useContext, useCallback } from "react";

// ─── GOOGLE FONTS ───────────────────────────────────────────────────────────
const FontLoader = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=Outfit:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap');
  `}</style>
);

// ─── GLOBAL STYLES ──────────────────────────────────────────────────────────
const GlobalStyles = () => (
  <style>{`
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    html { scroll-behavior: smooth; }
    body { font-family: 'Outfit', sans-serif; }
    ::-webkit-scrollbar { width: 5px; }
    ::-webkit-scrollbar-track { background: #0f1117; }
    ::-webkit-scrollbar-thumb { background: #2a3a5c; border-radius: 4px; }
    ::selection { background: rgba(99,102,241,0.35); color: #fff; }

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(28px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    @keyframes fadeIn {
      from { opacity: 0; } to { opacity: 1; }
    }
    @keyframes slideRight {
      from { transform: scaleX(0); } to { transform: scaleX(1); }
    }
    @keyframes pulse {
      0%,100% { opacity:1; } 50% { opacity:.45; }
    }
    @keyframes spin {
      from { transform: rotate(0deg); } to { transform: rotate(360deg); }
    }
    @keyframes float {
      0%,100% { transform: translateY(0); }
      50%      { transform: translateY(-12px); }
    }
    @keyframes gradShift {
      0%   { background-position: 0% 50%; }
      50%  { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }
    @keyframes glow {
      0%,100% { box-shadow: 0 0 20px rgba(99,102,241,.3); }
      50%      { box-shadow: 0 0 40px rgba(99,102,241,.6); }
    }
    @keyframes scanline {
      0%   { top: -4px; }
      100% { top: 100%; }
    }

    .fu  { animation: fadeUp .6s cubic-bezier(.4,0,.2,1) both; }
    .fu1 { animation-delay:.08s; }
    .fu2 { animation-delay:.16s; }
    .fu3 { animation-delay:.24s; }
    .fu4 { animation-delay:.32s; }
    .fu5 { animation-delay:.40s; }
    .fu6 { animation-delay:.48s; }

    .btn-primary {
      background: linear-gradient(135deg,#6366f1,#8b5cf6,#06b6d4);
      background-size: 200% 200%;
      animation: gradShift 4s ease infinite;
      color: #fff; border: none; border-radius: 12px;
      padding: 12px 28px; font-size: 15px; font-weight: 600;
      font-family: 'Outfit', sans-serif;
      cursor: pointer; transition: transform .2s, box-shadow .2s;
      letter-spacing: -.2px;
    }
    .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 30px rgba(99,102,241,.45); }
    .btn-primary:active { transform: translateY(0); }
    .btn-primary:disabled { opacity: .45; cursor: not-allowed; transform: none; }

    .btn-ghost {
      background: rgba(255,255,255,.06);
      border: 1px solid rgba(255,255,255,.1);
      color: #94a3b8; border-radius: 10px;
      padding: 10px 22px; font-size: 14px; font-weight: 500;
      font-family: 'Outfit', sans-serif;
      cursor: pointer; transition: all .2s;
    }
    .btn-ghost:hover { background: rgba(255,255,255,.1); color: #e2e8f0; border-color: rgba(255,255,255,.18); }

    .glass-card {
      background: rgba(15,18,30,.75);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255,255,255,.08);
      border-radius: 20px;
    }
    .glass-card-light {
      background: rgba(255,255,255,.03);
      backdrop-filter: blur(16px);
      border: 1px solid rgba(255,255,255,.06);
      border-radius: 16px;
    }

    input, textarea {
      font-family: 'Outfit', sans-serif;
      background: rgba(255,255,255,.04);
      border: 1px solid rgba(255,255,255,.1);
      border-radius: 12px;
      color: #e2e8f0;
      font-size: 14px;
      transition: border-color .2s, box-shadow .2s;
    }
    input::placeholder, textarea::placeholder { color: #475569; }
    input:focus, textarea:focus {
      outline: none;
      border-color: rgba(99,102,241,.6);
      box-shadow: 0 0 0 3px rgba(99,102,241,.12);
    }

    .nav-link {
      color: #64748b; font-size: 14px; font-weight: 500;
      cursor: pointer; text-decoration: none;
      padding: 6px 12px; border-radius: 8px;
      transition: color .2s, background .2s;
    }
    .nav-link:hover, .nav-link.active { color: #e2e8f0; background: rgba(255,255,255,.06); }

    .score-ring { transition: stroke-dashoffset 1.4s cubic-bezier(.4,0,.2,1); }
    .bar-fill { transition: width 1.4s cubic-bezier(.4,0,.2,1); }

    .tag {
      display: inline-flex; align-items: center; gap: 6px;
      background: rgba(99,102,241,.12); border: 1px solid rgba(99,102,241,.25);
      color: #a5b4fc; border-radius: 99px;
      padding: 4px 12px; font-size: 12px; font-weight: 500;
      font-family: 'JetBrains Mono', monospace;
    }
    .tag-green {
      background: rgba(16,185,129,.1); border-color: rgba(16,185,129,.25); color: #6ee7b7;
    }
    .tag-red {
      background: rgba(239,68,68,.1); border-color: rgba(239,68,68,.25); color: #fca5a5;
    }
    .tag-amber {
      background: rgba(245,158,11,.1); border-color: rgba(245,158,11,.25); color: #fcd34d;
    }

    .sidebar-item {
      display: flex; align-items: center; gap: 12px;
      padding: 10px 14px; border-radius: 10px;
      color: #64748b; font-size: 14px; font-weight: 500;
      cursor: pointer; transition: all .2s; margin-bottom: 2px;
    }
    .sidebar-item:hover { background: rgba(255,255,255,.05); color: #cbd5e1; }
    .sidebar-item.active {
      background: linear-gradient(135deg,rgba(99,102,241,.2),rgba(139,92,246,.15));
      color: #a5b4fc;
      border-left: 2px solid #6366f1;
    }

    .report-card:hover {
      border-color: rgba(99,102,241,.35) !important;
      transform: translateY(-2px);
      box-shadow: 0 12px 40px rgba(0,0,0,.3) !important;
    }

    .feature-card:hover {
      border-color: rgba(99,102,241,.3) !important;
      transform: translateY(-4px);
    }
  `}</style>
);

// ─── CONTEXT ────────────────────────────────────────────────────────────────
const AppCtx = createContext(null);

function useApp() { return useContext(AppCtx); }

// ─── LOCAL DB HELPERS ────────────────────────────────────────────────────────
const DB = {
  getUsers: () => JSON.parse(localStorage.getItem("liai_users") || "[]"),
  saveUsers: (u) => localStorage.setItem("liai_users", JSON.stringify(u)),
  getReports: () => JSON.parse(localStorage.getItem("liai_reports") || "[]"),
  saveReports: (r) => localStorage.setItem("liai_reports", JSON.stringify(r)),
  getSession: () => JSON.parse(localStorage.getItem("liai_session") || "null"),
  saveSession: (s) => localStorage.setItem("liai_session", JSON.stringify(s)),
  clearSession: () => localStorage.removeItem("liai_session"),
};

function hashPw(pw) {
  let h = 0;
  for (let i = 0; i < pw.length; i++) h = ((h << 5) - h + pw.charCodeAt(i)) | 0;
  return h.toString(16);
}

// ─── AI ANALYSIS ─────────────────────────────────────────────────────────────
async function runAIAnalysis(profileText) {
  const system = `You are a world-class LinkedIn recruiter and ATS optimization expert. Analyze the LinkedIn profile and return ONLY valid JSON. No markdown, no explanation, no extra text outside the JSON object.

Return exactly this structure:
{
  "profile_score": <integer 0-100>,
  "strengths": [<3-5 strings>],
  "weaknesses": [<3-5 strings>],
  "improved_headline": "<optimized ATS headline string>",
  "improved_about": "<optimized About section, 3-4 sentences>",
  "missing_skills": [<5-8 skill strings relevant to modern tech/industry>],
  "job_roles": [<4-6 job title strings this person qualifies for>],
  "improvement_plan": [<4-6 actionable step strings>]
}

Be strict, recruiter-level realistic. Focus on ATS optimization. Use modern keywords: AI, ML, Cloud, DevOps, APIs, Data, SaaS, etc.`;

  const resp = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1500,
      system,
      messages: [{ role: "user", content: `Analyze this LinkedIn profile:\n\n${profileText}` }],
    }),
  });

  if (!resp.ok) {
    const errData = await resp.json().catch(() => ({}));
    throw new Error(errData?.error?.message || `API error ${resp.status}`);
  }

  const data = await resp.json();
  const raw = data.content?.map(b => b.text || "").join("") || "";
  const clean = raw.replace(/```json|```/g, "").trim();
  const match = clean.match(/\{[\s\S]*\}/);
  if (!match) throw new Error("Invalid AI response format");
  return JSON.parse(match[0]);
}

// ─── ICONS ───────────────────────────────────────────────────────────────────
const Icon = {
  logo: () => (
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
      <rect width="32" height="32" rx="9" fill="url(#lg)"/>
      <defs><linearGradient id="lg" x1="0" y1="0" x2="32" y2="32">
        <stop stopColor="#6366f1"/><stop offset="1" stopColor="#06b6d4"/>
      </linearGradient></defs>
      <text x="6" y="23" fontFamily="'JetBrains Mono'" fontWeight="700" fontSize="16" fill="white">in</text>
    </svg>
  ),
  dashboard: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>,
  analyze: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>,
  reports: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>,
  logout: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>,
  check: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>,
  x: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
  star: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>,
  arrow: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>,
  bolt: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>,
  brain: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96-.46 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 1.98-3A2.5 2.5 0 0 1 9.5 2Z"/><path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96-.46 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3A2.5 2.5 0 0 0 14.5 2Z"/></svg>,
  shield: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>,
  chart: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>,
  clock: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>,
  user: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
  eye: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>,
  mail: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>,
  lock: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>,
};

// ─── SCORE RING ──────────────────────────────────────────────────────────────
function ScoreRing({ score, size = 130, stroke = 11 }) {
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (score / 100) * circ;
  const color = score >= 80 ? "#10b981" : score >= 60 ? "#f59e0b" : score >= 40 ? "#f97316" : "#ef4444";
  const label = score >= 80 ? "Excellent" : score >= 60 ? "Good" : score >= 40 ? "Fair" : "Needs Work";

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
      <div style={{ position: "relative", width: size, height: size }}>
        <svg width={size} height={size} style={{ transform: "rotate(-90deg)", position: "absolute" }}>
          <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,.06)" strokeWidth={stroke}/>
          <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={stroke}
            strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round" className="score-ring"/>
        </svg>
        <div style={{
          position: "absolute", inset: 0, display: "flex", flexDirection: "column",
          alignItems: "center", justifyContent: "center",
        }}>
          <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: size*0.2, fontWeight: 700, color }}>{score}</span>
          <span style={{ fontSize: 10, color: "#64748b", fontWeight: 500, marginTop: 2 }}>/ 100</span>
        </div>
      </div>
      <span style={{
        fontSize: 12, fontWeight: 600, color,
        background: `${color}18`, border: `1px solid ${color}35`,
        borderRadius: 99, padding: "3px 10px",
        fontFamily: "'JetBrains Mono',monospace",
      }}>{label}</span>
    </div>
  );
}

// ─── NAVBAR (LANDING) ────────────────────────────────────────────────────────
function LandingNav({ setPage }) {
  return (
    <nav style={{
      position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
      background: "rgba(9,11,21,.85)", backdropFilter: "blur(20px)",
      borderBottom: "1px solid rgba(255,255,255,.07)",
      padding: "0 32px", height: 64,
      display: "flex", alignItems: "center", justifyContent: "space-between",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <Icon.logo />
        <span style={{ fontFamily: "'Syne',sans-serif", fontWeight: 700, fontSize: 17, color: "#e2e8f0" }}>
          LinkedAI<span style={{ color: "#6366f1" }}>Pro</span>
        </span>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <span className="nav-link" onClick={() => setPage("login")}>Sign in</span>
        <button className="btn-primary" style={{ padding: "8px 20px", fontSize: 14 }} onClick={() => setPage("register")}>
          Get Started
        </button>
      </div>
    </nav>
  );
}

// ─── SIDEBAR (APP) ────────────────────────────────────────────────────────────
function Sidebar({ page, setPage, user, logout }) {
  const items = [
    { id: "dashboard", label: "Dashboard", icon: Icon.dashboard },
    { id: "analyzer", label: "AI Analyzer", icon: Icon.analyze },
    { id: "reports", label: "My Reports", icon: Icon.reports },
  ];

  return (
    <aside style={{
      width: 240, flexShrink: 0,
      background: "rgba(9,11,21,.95)",
      borderRight: "1px solid rgba(255,255,255,.07)",
      display: "flex", flexDirection: "column",
      padding: "24px 16px",
      height: "100vh", position: "sticky", top: 0,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 36, paddingLeft: 4 }}>
        <Icon.logo />
        <span style={{ fontFamily: "'Syne',sans-serif", fontWeight: 700, fontSize: 16, color: "#e2e8f0" }}>
          LinkedAI<span style={{ color: "#6366f1" }}>Pro</span>
        </span>
      </div>

      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 11, color: "#334155", letterSpacing: ".1em", textTransform: "uppercase", padding: "0 14px", marginBottom: 8, fontWeight: 600 }}>
          Navigation
        </div>
        {items.map(({ id, label, icon: Ico }) => (
          <div key={id} className={`sidebar-item ${page === id ? "active" : ""}`} onClick={() => setPage(id)}>
            <Ico />{label}
          </div>
        ))}
      </div>

      <div style={{
        borderTop: "1px solid rgba(255,255,255,.06)",
        paddingTop: 16, marginTop: 16,
      }}>
        <div style={{
          display: "flex", alignItems: "center", gap: 10,
          padding: "10px 14px", marginBottom: 8,
        }}>
          <div style={{
            width: 34, height: 34, borderRadius: "50%",
            background: "linear-gradient(135deg,#6366f1,#8b5cf6)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 14, fontWeight: 700, color: "#fff",
          }}>{user?.name?.[0]?.toUpperCase() || "U"}</div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#cbd5e1" }}>{user?.name || "User"}</div>
            <div style={{ fontSize: 11, color: "#475569", maxWidth: 120, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{user?.email}</div>
          </div>
        </div>
        <div className="sidebar-item" onClick={logout} style={{ color: "#ef4444" }}>
          <Icon.logout /> Sign Out
        </div>
      </div>
    </aside>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: LANDING
// ═══════════════════════════════════════════════════════════════════
function LandingPage({ setPage }) {
  const features = [
    { icon: Icon.brain, title: "AI-Powered Analysis", desc: "Claude AI evaluates your profile like a senior recruiter — scoring every section against real hiring standards.", color: "#6366f1" },
    { icon: Icon.chart, title: "ATS Score & Gaps", desc: "Understand exactly how Applicant Tracking Systems see your profile and which keywords are missing.", color: "#06b6d4" },
    { icon: Icon.bolt, title: "Instant Improvements", desc: "Get a rewritten headline, optimized About section, and a step-by-step improvement roadmap.", color: "#f59e0b" },
    { icon: Icon.shield, title: "Secure & Private", desc: "Your data is encrypted and stored securely. We never share your profile with third parties.", color: "#10b981" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "#090b15", color: "#e2e8f0" }}>
      <LandingNav setPage={setPage} />

      {/* Decorative BG */}
      <div style={{ position: "fixed", inset: 0, zIndex: 0, overflow: "hidden", pointerEvents: "none" }}>
        <div style={{ position: "absolute", top: "10%", left: "20%", width: 500, height: 500, background: "radial-gradient(circle,rgba(99,102,241,.12) 0%,transparent 70%)", borderRadius: "50%" }}/>
        <div style={{ position: "absolute", bottom: "20%", right: "15%", width: 400, height: 400, background: "radial-gradient(circle,rgba(6,182,212,.09) 0%,transparent 70%)", borderRadius: "50%" }}/>
      </div>

      {/* HERO */}
      <section style={{ position: "relative", zIndex: 1, paddingTop: 160, paddingBottom: 100, textAlign: "center", padding: "160px 24px 100px" }}>
        <div className="fu" style={{
          display: "inline-flex", alignItems: "center", gap: 8,
          background: "rgba(99,102,241,.1)", border: "1px solid rgba(99,102,241,.25)",
          borderRadius: 99, padding: "6px 16px", marginBottom: 28,
          fontSize: 12, fontWeight: 600, color: "#a5b4fc",
          fontFamily: "'JetBrains Mono',monospace", letterSpacing: ".06em",
        }}>
          <Icon.bolt /> AI-POWERED · RECRUITER-GRADE · FREE TO START
        </div>

        <h1 className="fu fu1" style={{
          fontFamily: "'Syne',sans-serif",
          fontSize: "clamp(36px,7vw,80px)",
          fontWeight: 800, lineHeight: 1.05,
          letterSpacing: "-2px", marginBottom: 24,
          background: "linear-gradient(135deg,#e2e8f0 30%,#a5b4fc 65%,#67e8f9)",
          WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
        }}>
          Supercharge Your<br />LinkedIn Profile
        </h1>

        <p className="fu fu2" style={{
          fontSize: "clamp(15px,2vw,19px)", color: "#64748b", lineHeight: 1.7,
          maxWidth: 560, margin: "0 auto 44px",
        }}>
          Paste your profile. Get an AI analysis in seconds. Land more interviews with a recruiter-optimized, ATS-ready LinkedIn profile.
        </p>

        <div className="fu fu3" style={{ display: "flex", gap: 14, justifyContent: "center", flexWrap: "wrap" }}>
          <button className="btn-primary" style={{ padding: "14px 36px", fontSize: 16, borderRadius: 14 }} onClick={() => setPage("register")}>
            Start Free Analysis →
          </button>
          <button className="btn-ghost" style={{ padding: "14px 28px", fontSize: 15 }} onClick={() => setPage("login")}>
            Sign In
          </button>
        </div>

        {/* Mockup stats */}
        <div className="fu fu4" style={{
          display: "flex", gap: 20, justifyContent: "center",
          marginTop: 64, flexWrap: "wrap",
        }}>
          {[["10,000+","Profiles Analyzed"],["94%","Interview Rate Boost"],["< 30s","Analysis Time"],["Free","Always"]].map(([n,l]) => (
            <div key={l} className="glass-card-light" style={{ padding: "18px 28px", textAlign: "center", minWidth: 130 }}>
              <div style={{ fontFamily: "'Syne',sans-serif", fontSize: 24, fontWeight: 800, color: "#a5b4fc", letterSpacing: "-1px" }}>{n}</div>
              <div style={{ fontSize: 12, color: "#475569", marginTop: 4 }}>{l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURES */}
      <section style={{ position: "relative", zIndex: 1, maxWidth: 1100, margin: "0 auto", padding: "60px 24px 120px" }}>
        <div style={{ textAlign: "center", marginBottom: 56 }}>
          <h2 style={{ fontFamily: "'Syne',sans-serif", fontSize: "clamp(26px,4vw,42px)", fontWeight: 800, letterSpacing: "-1px", marginBottom: 14 }}>
            Everything You Need to<br /><span style={{ color: "#6366f1" }}>Stand Out</span>
          </h2>
          <p style={{ color: "#64748b", fontSize: 16, maxWidth: 480, margin: "0 auto" }}>
            Our AI doesn't just score — it transforms your profile into a recruiter magnet.
          </p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(240px,1fr))", gap: 20 }}>
          {features.map(({ icon: Ico, title, desc, color }) => (
            <div key={title} className="glass-card feature-card" style={{ padding: "28px 24px", transition: "all .3s" }}>
              <div style={{
                width: 46, height: 46, borderRadius: 12,
                background: `${color}18`, border: `1px solid ${color}30`,
                display: "flex", alignItems: "center", justifyContent: "center",
                color, marginBottom: 18,
              }}><Ico /></div>
              <div style={{ fontFamily: "'Syne',sans-serif", fontWeight: 700, fontSize: 16, marginBottom: 10, color: "#e2e8f0" }}>{title}</div>
              <div style={{ fontSize: 13.5, color: "#64748b", lineHeight: 1.65 }}>{desc}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA BANNER */}
      <section style={{ position: "relative", zIndex: 1, padding: "0 24px 100px" }}>
        <div style={{
          maxWidth: 720, margin: "0 auto",
          background: "linear-gradient(135deg,rgba(99,102,241,.15),rgba(6,182,212,.1))",
          border: "1px solid rgba(99,102,241,.25)",
          borderRadius: 24, padding: "52px 40px", textAlign: "center",
          animation: "glow 3s ease infinite",
        }}>
          <h3 style={{ fontFamily: "'Syne',sans-serif", fontSize: 30, fontWeight: 800, letterSpacing: "-1px", marginBottom: 14 }}>
            Ready to 10x Your LinkedIn?
          </h3>
          <p style={{ color: "#64748b", fontSize: 15, marginBottom: 28 }}>
            Join thousands of professionals who optimized their profiles with AI.
          </p>
          <button className="btn-primary" style={{ padding: "14px 40px", fontSize: 16 }} onClick={() => setPage("register")}>
            Analyze My Profile — Free
          </button>
        </div>
      </section>

      <footer style={{ borderTop: "1px solid rgba(255,255,255,.05)", textAlign: "center", padding: "24px", fontSize: 13, color: "#334155", position: "relative", zIndex: 1 }}>
        © 2025 LinkedAIPro · Built with Claude AI · All rights reserved
      </footer>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: AUTH (LOGIN / REGISTER)
// ═══════════════════════════════════════════════════════════════════
function AuthPage({ mode, setPage, onLogin }) {
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPw, setShowPw] = useState(false);

  const isLogin = mode === "login";

  function submit() {
    setErr(""); setLoading(true);
    setTimeout(() => {
      try {
        if (!form.email || !form.password) throw new Error("All fields required");
        if (!isLogin && !form.name) throw new Error("Name is required");

        const users = DB.getUsers();
        if (isLogin) {
          const u = users.find(u => u.email === form.email && u.passwordHash === hashPw(form.password));
          if (!u) throw new Error("Invalid email or password");
          DB.saveSession(u);
          onLogin(u);
        } else {
          if (users.find(u => u.email === form.email)) throw new Error("Email already registered");
          if (form.password.length < 6) throw new Error("Password must be at least 6 characters");
          const u = { id: Date.now().toString(), name: form.name, email: form.email, passwordHash: hashPw(form.password), createdAt: new Date().toISOString() };
          DB.saveUsers([...users, u]);
          DB.saveSession(u);
          onLogin(u);
        }
      } catch (e) { setErr(e.message); }
      setLoading(false);
    }, 600);
  }

  return (
    <div style={{ minHeight: "100vh", background: "#090b15", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      {/* BG */}
      <div style={{ position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none" }}>
        <div style={{ position: "absolute", top: "30%", left: "50%", transform: "translate(-50%,-50%)", width: 600, height: 600, background: "radial-gradient(circle,rgba(99,102,241,.1) 0%,transparent 70%)", borderRadius: "50%" }}/>
      </div>

      <div className="glass-card fu" style={{ width: "100%", maxWidth: 420, padding: "40px 36px", position: "relative", zIndex: 1 }}>
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ display: "inline-flex", marginBottom: 16 }}><Icon.logo /></div>
          <h2 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 26, letterSpacing: "-1px", color: "#e2e8f0", marginBottom: 8 }}>
            {isLogin ? "Welcome back" : "Create account"}
          </h2>
          <p style={{ color: "#475569", fontSize: 14 }}>
            {isLogin ? "Sign in to your LinkedAIPro account" : "Start optimizing your LinkedIn profile"}
          </p>
        </div>

        {err && (
          <div style={{
            background: "rgba(239,68,68,.1)", border: "1px solid rgba(239,68,68,.25)",
            borderRadius: 10, padding: "11px 14px", marginBottom: 18,
            color: "#fca5a5", fontSize: 13,
          }}>{err}</div>
        )}

        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {!isLogin && (
            <div>
              <label style={{ fontSize: 12, color: "#64748b", fontWeight: 600, display: "block", marginBottom: 6, letterSpacing: ".05em" }}>FULL NAME</label>
              <div style={{ position: "relative" }}>
                <span style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", color: "#334155" }}><Icon.user /></span>
                <input value={form.name} onChange={e => setForm({...form, name: e.target.value})}
                  placeholder="John Doe"
                  style={{ width: "100%", padding: "12px 14px 12px 40px" }}
                />
              </div>
            </div>
          )}

          <div>
            <label style={{ fontSize: 12, color: "#64748b", fontWeight: 600, display: "block", marginBottom: 6, letterSpacing: ".05em" }}>EMAIL ADDRESS</label>
            <div style={{ position: "relative" }}>
              <span style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", color: "#334155" }}><Icon.mail /></span>
              <input type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})}
                placeholder="you@example.com"
                style={{ width: "100%", padding: "12px 14px 12px 40px" }}
                onKeyDown={e => e.key === "Enter" && submit()}
              />
            </div>
          </div>

          <div>
            <label style={{ fontSize: 12, color: "#64748b", fontWeight: 600, display: "block", marginBottom: 6, letterSpacing: ".05em" }}>PASSWORD</label>
            <div style={{ position: "relative" }}>
              <span style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", color: "#334155" }}><Icon.lock /></span>
              <input type={showPw ? "text" : "password"} value={form.password}
                onChange={e => setForm({...form, password: e.target.value})}
                placeholder={isLogin ? "Your password" : "Min. 6 characters"}
                style={{ width: "100%", padding: "12px 42px 12px 40px" }}
                onKeyDown={e => e.key === "Enter" && submit()}
              />
              <span onClick={() => setShowPw(!showPw)} style={{ position: "absolute", right: 14, top: "50%", transform: "translateY(-50%)", color: "#334155", cursor: "pointer" }}>
                <Icon.eye />
              </span>
            </div>
          </div>

          <button className="btn-primary" onClick={submit} disabled={loading}
            style={{ padding: "13px", fontSize: 15, marginTop: 4, borderRadius: 12 }}>
            {loading ? "Please wait..." : isLogin ? "Sign In" : "Create Account"}
          </button>
        </div>

        <div style={{ textAlign: "center", marginTop: 22, fontSize: 13, color: "#475569" }}>
          {isLogin ? "Don't have an account? " : "Already have an account? "}
          <span onClick={() => setPage(isLogin ? "register" : "login")}
            style={{ color: "#6366f1", cursor: "pointer", fontWeight: 600 }}>
            {isLogin ? "Sign up" : "Sign in"}
          </span>
        </div>
        <div style={{ textAlign: "center", marginTop: 10 }}>
          <span onClick={() => setPage("landing")} style={{ fontSize: 12, color: "#334155", cursor: "pointer" }}>
            ← Back to home
          </span>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: DASHBOARD
// ═══════════════════════════════════════════════════════════════════
function DashboardPage({ user, setPage }) {
  const reports = DB.getReports().filter(r => r.userId === user.id);
  const avgScore = reports.length ? Math.round(reports.reduce((a, r) => a + (r.result?.profile_score || 0), 0) / reports.length) : 0;
  const lastReport = reports[reports.length - 1];

  const stats = [
    { label: "Profile Score", value: avgScore || "—", sub: "avg across analyses", color: "#6366f1", icon: Icon.chart },
    { label: "Reports Generated", value: reports.length, sub: "total analyses done", color: "#06b6d4", icon: Icon.reports },
    { label: "Latest Score", value: lastReport?.result?.profile_score ?? "—", sub: "most recent analysis", color: "#10b981", icon: Icon.star },
    { label: "Member Since", value: new Date(user.createdAt).toLocaleDateString("en", {month:"short",year:"numeric"}), sub: "account created", color: "#f59e0b", icon: Icon.shield },
  ];

  return (
    <div style={{ padding: "40px 40px 60px", maxWidth: 1100, margin: "0 auto" }}>
      {/* Welcome */}
      <div className="fu" style={{ marginBottom: 36 }}>
        <h1 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 30, letterSpacing: "-1px", marginBottom: 6 }}>
          Welcome back, {user.name?.split(" ")[0]} 👋
        </h1>
        <p style={{ color: "#475569", fontSize: 15 }}>
          {reports.length === 0
            ? "You haven't run an analysis yet. Let's optimize your LinkedIn profile!"
            : `You have ${reports.length} report${reports.length>1?"s":""} saved. Keep improving!`}
        </p>
      </div>

      {/* Stats Grid */}
      <div className="fu fu1" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(210px,1fr))", gap: 18, marginBottom: 36 }}>
        {stats.map(({ label, value, sub, color, icon: Ico }) => (
          <div key={label} className="glass-card" style={{ padding: "24px 22px" }}>
            <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 14 }}>
              <div style={{ fontSize: 12, color: "#475569", fontWeight: 600, letterSpacing: ".05em", textTransform: "uppercase" }}>{label}</div>
              <div style={{ width: 34, height: 34, borderRadius: 9, background: `${color}18`, border: `1px solid ${color}25`, display: "flex", alignItems: "center", justifyContent: "center", color }}><Ico /></div>
            </div>
            <div style={{ fontFamily: "'Syne',sans-serif", fontSize: 32, fontWeight: 800, color, letterSpacing: "-1px", marginBottom: 4 }}>{value}</div>
            <div style={{ fontSize: 12, color: "#334155" }}>{sub}</div>
          </div>
        ))}
      </div>

      {/* CTA */}
      <div className="fu fu2" style={{
        background: "linear-gradient(135deg,rgba(99,102,241,.12),rgba(139,92,246,.08))",
        border: "1px solid rgba(99,102,241,.2)",
        borderRadius: 20, padding: "32px 28px",
        display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 20,
      }}>
        <div>
          <div style={{ fontFamily: "'Syne',sans-serif", fontWeight: 700, fontSize: 20, marginBottom: 6 }}>
            {reports.length === 0 ? "Run Your First AI Analysis" : "Analyze Again to Track Progress"}
          </div>
          <div style={{ color: "#64748b", fontSize: 14 }}>
            Paste your LinkedIn profile and get instant AI-powered feedback.
          </div>
        </div>
        <button className="btn-primary" style={{ padding: "12px 28px", whiteSpace: "nowrap" }} onClick={() => setPage("analyzer")}>
          New Analysis →
        </button>
      </div>

      {/* Recent Reports */}
      {reports.length > 0 && (
        <div className="fu fu3" style={{ marginTop: 36 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
            <h2 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 700, fontSize: 18 }}>Recent Reports</h2>
            <span onClick={() => setPage("reports")} style={{ fontSize: 13, color: "#6366f1", cursor: "pointer", fontWeight: 500 }}>View all →</span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {reports.slice(-3).reverse().map(r => (
              <ReportRow key={r.id} report={r} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: ANALYZER
// ═══════════════════════════════════════════════════════════════════
function AnalyzerPage({ user, setPage }) {
  const [text, setText] = useState("");
  const [stage, setStage] = useState("input"); // input | loading | result
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  async function analyze() {
    if (text.trim().length < 80) { setError("Please paste more profile content (at least 80 characters)."); return; }
    setError(""); setStage("loading");
    try {
      const ai = await runAIAnalysis(text);
      const report = {
        id: Date.now().toString(),
        userId: user.id,
        inputText: text.slice(0, 500),
        result: ai,
        createdAt: new Date().toISOString(),
      };
      DB.saveReports([...DB.getReports(), report]);
      setResult(ai);
      setStage("result");
    } catch (e) {
      setError(`Analysis failed: ${e.message || "Unknown error"}. Please try again.`);
      setStage("input");
    }
  }

  function reset() { setText(""); setResult(null); setStage("input"); setError(""); }

  return (
    <div style={{ padding: "40px 40px 60px", maxWidth: 900, margin: "0 auto" }}>
      <div className="fu" style={{ marginBottom: 32 }}>
        <h1 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 28, letterSpacing: "-1px", marginBottom: 6 }}>AI Profile Analyzer</h1>
        <p style={{ color: "#475569", fontSize: 14 }}>Paste your LinkedIn profile and get a recruiter-level analysis in seconds.</p>
      </div>

      {stage === "input" && (
        <div className="fu fu1">
          <div className="glass-card" style={{ padding: "28px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 18 }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#6366f1", animation: "pulse 2s infinite" }}/>
              <span style={{ fontSize: 13, color: "#64748b", fontWeight: 500 }}>
                Include headline, About, experience, skills, and education for the best results.
              </span>
            </div>
            <textarea
              value={text} onChange={e => setText(e.target.value)}
              placeholder={`Paste your full LinkedIn profile here...\n\nExample:\nSoftware Engineer at TechCorp | 5+ years building scalable web apps\n\nAbout:\nI'm a passionate software engineer...\n\nExperience:\nSenior Engineer, TechCorp (2021–Present)\n• Led migration to microservices architecture...\n\nSkills: Python, React, AWS, Docker, PostgreSQL`}
              style={{ width: "100%", minHeight: 300, padding: "18px", lineHeight: 1.7, resize: "vertical", fontSize: 14 }}
            />
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 16 }}>
              <span style={{ fontSize: 12, color: "#334155", fontFamily: "'JetBrains Mono',monospace" }}>{text.length} chars</span>
              <div style={{ display: "flex", gap: 10 }}>
                {text && <button className="btn-ghost" style={{ fontSize: 13, padding: "8px 16px" }} onClick={() => setText("")}>Clear</button>}
                <button className="btn-primary" disabled={text.length < 80} onClick={analyze} style={{ padding: "10px 24px", fontSize: 14 }}>
                  Analyze Profile →
                </button>
              </div>
            </div>
            {error && <div style={{ marginTop: 12, color: "#fca5a5", fontSize: 13, background: "rgba(239,68,68,.08)", borderRadius: 8, padding: "10px 14px" }}>{error}</div>}
          </div>
        </div>
      )}

      {stage === "loading" && (
        <div className="glass-card" style={{ padding: "70px 40px", textAlign: "center" }}>
          <div style={{ width: 60, height: 60, margin: "0 auto 24px", border: "3px solid rgba(99,102,241,.3)", borderTopColor: "#6366f1", borderRadius: "50%", animation: "spin 1s linear infinite" }}/>
          <div style={{ fontFamily: "'Syne',sans-serif", fontSize: 20, fontWeight: 700, marginBottom: 10 }}>Analyzing Your Profile...</div>
          <p style={{ color: "#475569", fontSize: 14 }}>AI is reviewing your profile against recruiter and ATS standards.</p>
          <div style={{ display: "flex", gap: 8, justifyContent: "center", marginTop: 24, flexWrap: "wrap" }}>
            {["Scanning headline","Reviewing experience","Checking ATS keywords","Scoring sections"].map((s, i) => (
              <span key={s} style={{ fontSize: 11, color: "#4a5568", background: "rgba(99,102,241,.08)", border: "1px solid rgba(99,102,241,.15)", borderRadius: 99, padding: "4px 12px", fontFamily: "'JetBrains Mono',monospace", animation: `pulse 1.5s ${i*.3}s infinite` }}>{s}</span>
            ))}
          </div>
        </div>
      )}

      {stage === "result" && result && (
        <AnalysisResult result={result} onReset={reset} onViewReports={() => setPage("reports")} />
      )}
    </div>
  );
}

// ─── ANALYSIS RESULT COMPONENT ───────────────────────────────────────────────
function AnalysisResult({ result, onReset, onViewReports }) {
  const score = result.profile_score || 0;

  return (
    <div>
      {/* Score Header */}
      <div className="fu glass-card" style={{ padding: "32px 28px", marginBottom: 20, display: "flex", alignItems: "center", gap: 28, flexWrap: "wrap" }}>
        <ScoreRing score={score} size={130} />
        <div style={{ flex: 1, minWidth: 200 }}>
          <div style={{ fontSize: 12, color: "#475569", fontWeight: 600, letterSpacing: ".08em", textTransform: "uppercase", marginBottom: 8 }}>Analysis Complete</div>
          <h2 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 22, letterSpacing: "-.5px", marginBottom: 10 }}>
            {score >= 80 ? "🏆 Outstanding Profile" : score >= 65 ? "✅ Strong Profile" : score >= 45 ? "⚡ Decent — Needs Polish" : "🔧 Significant Room to Grow"}
          </h2>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <button className="btn-primary" style={{ padding: "9px 20px", fontSize: 13 }} onClick={onViewReports}>View All Reports</button>
            <button className="btn-ghost" style={{ padding: "9px 18px", fontSize: 13 }} onClick={onReset}>New Analysis</button>
          </div>
        </div>
      </div>

      {/* Grid Results */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(380px,1fr))", gap: 18, marginBottom: 20 }}>
        {/* Strengths */}
        <ResultCard title="Strengths" icon="💪" color="#10b981" items={result.strengths} type="check" />
        {/* Weaknesses */}
        <ResultCard title="Weaknesses" icon="⚠️" color="#ef4444" items={result.weaknesses} type="x" />
      </div>

      {/* Improved Headline */}
      {result.improved_headline && (
        <div className="glass-card fu" style={{ padding: "22px 24px", marginBottom: 18 }}>
          <div style={{ fontSize: 11, color: "#6366f1", fontWeight: 700, letterSpacing: ".1em", textTransform: "uppercase", marginBottom: 10, fontFamily: "'JetBrains Mono',monospace" }}>
            ✨ AI-Optimized Headline
          </div>
          <div style={{ fontSize: 16, fontWeight: 600, color: "#e2e8f0", lineHeight: 1.5, background: "rgba(99,102,241,.06)", border: "1px solid rgba(99,102,241,.2)", borderRadius: 10, padding: "14px 16px" }}>
            {result.improved_headline}
          </div>
        </div>
      )}

      {/* Improved About */}
      {result.improved_about && (
        <div className="glass-card fu fu1" style={{ padding: "22px 24px", marginBottom: 18 }}>
          <div style={{ fontSize: 11, color: "#06b6d4", fontWeight: 700, letterSpacing: ".1em", textTransform: "uppercase", marginBottom: 10, fontFamily: "'JetBrains Mono',monospace" }}>
            ✨ AI-Optimized About Section
          </div>
          <div style={{ fontSize: 14, color: "#94a3b8", lineHeight: 1.75, background: "rgba(6,182,212,.04)", border: "1px solid rgba(6,182,212,.15)", borderRadius: 10, padding: "14px 16px" }}>
            {result.improved_about}
          </div>
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))", gap: 18, marginBottom: 18 }}>
        {/* Missing Skills */}
        {result.missing_skills?.length > 0 && (
          <div className="glass-card fu fu2" style={{ padding: "22px 24px" }}>
            <div style={{ fontSize: 11, color: "#f59e0b", fontWeight: 700, letterSpacing: ".1em", textTransform: "uppercase", marginBottom: 14, fontFamily: "'JetBrains Mono',monospace" }}>🎯 Missing Skills</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
              {result.missing_skills.map(s => <span key={s} className="tag tag-amber">{s}</span>)}
            </div>
          </div>
        )}
        {/* Job Roles */}
        {result.job_roles?.length > 0 && (
          <div className="glass-card fu fu2" style={{ padding: "22px 24px" }}>
            <div style={{ fontSize: 11, color: "#6366f1", fontWeight: 700, letterSpacing: ".1em", textTransform: "uppercase", marginBottom: 14, fontFamily: "'JetBrains Mono',monospace" }}>💼 Matching Job Roles</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
              {result.job_roles.map(r => <span key={r} className="tag">{r}</span>)}
            </div>
          </div>
        )}
      </div>

      {/* Improvement Plan */}
      {result.improvement_plan?.length > 0 && (
        <div className="glass-card fu fu3" style={{ padding: "22px 24px" }}>
          <div style={{ fontSize: 11, color: "#8b5cf6", fontWeight: 700, letterSpacing: ".1em", textTransform: "uppercase", marginBottom: 16, fontFamily: "'JetBrains Mono',monospace" }}>🗺️ Improvement Roadmap</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {result.improvement_plan.map((step, i) => (
              <div key={i} style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
                <div style={{
                  width: 26, height: 26, flexShrink: 0, borderRadius: "50%",
                  background: "linear-gradient(135deg,#6366f1,#8b5cf6)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 11, fontWeight: 700, color: "#fff", fontFamily: "'JetBrains Mono',monospace",
                }}>{i + 1}</div>
                <div style={{ fontSize: 14, color: "#94a3b8", lineHeight: 1.65, paddingTop: 4 }}>{step}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ResultCard({ title, icon, color, items = [], type }) {
  return (
    <div className="glass-card fu" style={{ padding: "22px 24px" }}>
      <div style={{ fontSize: 11, color, fontWeight: 700, letterSpacing: ".1em", textTransform: "uppercase", marginBottom: 14, fontFamily: "'JetBrains Mono',monospace" }}>
        {icon} {title}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {items.map((item, i) => (
          <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
            <span style={{ color, flexShrink: 0, marginTop: 2 }}>{type === "check" ? <Icon.check /> : <Icon.x />}</span>
            <span style={{ fontSize: 13.5, color: "#94a3b8", lineHeight: 1.6 }}>{item}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: REPORTS
// ═══════════════════════════════════════════════════════════════════
function ReportsPage({ user, setPage }) {
  const [selected, setSelected] = useState(null);
  const reports = DB.getReports().filter(r => r.userId === user.id).reverse();

  if (selected) {
    return (
      <div style={{ padding: "40px 40px 60px", maxWidth: 900, margin: "0 auto" }}>
        <button className="btn-ghost" style={{ marginBottom: 24, fontSize: 13, padding: "8px 16px" }} onClick={() => setSelected(null)}>← Back to Reports</button>
        <div style={{ marginBottom: 24 }}>
          <h1 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 24, letterSpacing: "-1px", marginBottom: 4 }}>Report Detail</h1>
          <span style={{ fontSize: 12, color: "#475569", display: "flex", alignItems: "center", gap: 6 }}>
            <Icon.clock /> {new Date(selected.createdAt).toLocaleString()}
          </span>
        </div>
        <AnalysisResult result={selected.result} onReset={() => { setSelected(null); setPage("analyzer"); }} onViewReports={() => setSelected(null)} />
      </div>
    );
  }

  return (
    <div style={{ padding: "40px 40px 60px", maxWidth: 900, margin: "0 auto" }}>
      <div className="fu" style={{ marginBottom: 32 }}>
        <h1 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 28, letterSpacing: "-1px", marginBottom: 6 }}>My Reports</h1>
        <p style={{ color: "#475569", fontSize: 14 }}>{reports.length} analysis report{reports.length !== 1 ? "s" : ""} saved to your account.</p>
      </div>

      {reports.length === 0 ? (
        <div className="glass-card fu fu1" style={{ padding: "60px 40px", textAlign: "center" }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>📊</div>
          <div style={{ fontFamily: "'Syne',sans-serif", fontWeight: 700, fontSize: 20, marginBottom: 10 }}>No Reports Yet</div>
          <p style={{ color: "#475569", fontSize: 14, marginBottom: 24 }}>Run your first AI analysis to generate a report.</p>
          <button className="btn-primary" onClick={() => setPage("analyzer")}>Start Analysis →</button>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {reports.map((r, i) => (
            <div key={r.id} className={`fu fu${Math.min(i+1,6)} glass-card report-card`}
              onClick={() => setSelected(r)}
              style={{ padding: "20px 22px", cursor: "pointer", transition: "all .25s", display: "flex", alignItems: "center", gap: 18, flexWrap: "wrap" }}>
              <ScoreRing score={r.result?.profile_score || 0} size={72} stroke={7} />
              <div style={{ flex: 1, minWidth: 180 }}>
                <div style={{ fontWeight: 600, fontSize: 14, color: "#e2e8f0", marginBottom: 6, display: "flex", alignItems: "center", gap: 8 }}>
                  LinkedIn Profile Analysis
                  <span style={{ fontSize: 11, color: "#475569", fontFamily: "'JetBrains Mono',monospace", fontWeight: 400 }}>
                    #{r.id.slice(-5)}
                  </span>
                </div>
                <div style={{ fontSize: 12, color: "#334155", display: "flex", alignItems: "center", gap: 6, marginBottom: 10 }}>
                  <Icon.clock /> {new Date(r.createdAt).toLocaleString()}
                </div>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {r.result?.job_roles?.slice(0, 2).map(role => (
                    <span key={role} className="tag" style={{ fontSize: 10, padding: "2px 9px" }}>{role}</span>
                  ))}
                  {r.result?.missing_skills?.slice(0, 2).map(sk => (
                    <span key={sk} className="tag tag-amber" style={{ fontSize: 10, padding: "2px 9px" }}>{sk}</span>
                  ))}
                </div>
              </div>
              <span style={{ color: "#475569", marginLeft: "auto" }}><Icon.arrow /></span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── REPORT ROW (mini) ────────────────────────────────────────────────────────
function ReportRow({ report }) {
  const score = report.result?.profile_score || 0;
  const color = score >= 80 ? "#10b981" : score >= 60 ? "#f59e0b" : "#ef4444";
  return (
    <div className="glass-card-light" style={{ padding: "14px 18px", display: "flex", alignItems: "center", gap: 14 }}>
      <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 18, fontWeight: 700, color, minWidth: 42 }}>{score}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, color: "#94a3b8", fontWeight: 500 }}>LinkedIn Analysis</div>
        <div style={{ fontSize: 11, color: "#334155", display: "flex", alignItems: "center", gap: 4, marginTop: 2 }}>
          <Icon.clock /> {new Date(report.createdAt).toLocaleDateString()}
        </div>
      </div>
      <div style={{ display: "flex", gap: 5 }}>
        {report.result?.job_roles?.slice(0,1).map(r => <span key={r} className="tag" style={{ fontSize: 10, padding: "2px 9px" }}>{r}</span>)}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// APP LAYOUT (authenticated)
// ═══════════════════════════════════════════════════════════════════
function AppLayout({ user, page, setPage, logout }) {
  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#090b15", color: "#e2e8f0" }}>
      <Sidebar page={page} setPage={setPage} user={user} logout={logout} />
      <main style={{ flex: 1, overflowY: "auto", minHeight: "100vh" }}>
        {page === "dashboard" && <DashboardPage user={user} setPage={setPage} />}
        {page === "analyzer"  && <AnalyzerPage  user={user} setPage={setPage} />}
        {page === "reports"   && <ReportsPage   user={user} setPage={setPage} />}
      </main>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// ROOT APP
// ═══════════════════════════════════════════════════════════════════
export default function App() {
  const [page, setPage] = useState("landing");
  const [user, setUser] = useState(null);

  useEffect(() => {
    const s = DB.getSession();
    if (s) { setUser(s); setPage("dashboard"); }
  }, []);

  function onLogin(u) { setUser(u); setPage("dashboard"); }
  function logout() { DB.clearSession(); setUser(null); setPage("landing"); }

  return (
    <>
      <FontLoader />
      <GlobalStyles />
      {!user && page === "landing"  && <LandingPage setPage={setPage} />}
      {!user && page === "login"    && <AuthPage mode="login"    setPage={setPage} onLogin={onLogin} />}
      {!user && page === "register" && <AuthPage mode="register" setPage={setPage} onLogin={onLogin} />}
      {user  && <AppLayout user={user} page={page} setPage={setPage} logout={logout} />}
    </>
  );
}
