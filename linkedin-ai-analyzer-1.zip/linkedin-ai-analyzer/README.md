# AI LinkedIn Profile Analyzer

An AI-powered SaaS web app that analyzes LinkedIn profiles and gives recruiter-level feedback.

## Features
- User Register & Login (JWT-style auth)
- AI Profile Analysis (Score, Strengths, Weaknesses, ATS Keywords)
- AI-rewritten Headline & About section
- Reports saved per user
- Dark glassmorphism SaaS UI

## Setup

1. Install dependencies:
```bash
npm install
```

2. Run locally:
```bash
npm run dev
```

3. Build for production:
```bash
npm run build
```

## Deploy to Vercel
1. Push to GitHub
2. Import repo on vercel.com
3. Click Deploy ✅
